﻿namespace DataTypes
{
    internal class Tester
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            
/*
            byte a;     --> Byte
            sbyte a;    --> SByte
            short a;    --> Short
            ushort a;   --> UShort
            int a;      --> Int32
            uint a;     --> UInt32
            long a;     --> Long
            ulong a;    --> ULong
            float a;    --> Single
            double a;   --> Double
            decimal a;  --> Decimal
            char a;     --> Char
            string a;   --> String
            bool a;     --> Boolean
            object a;   --> Object
*/
        }
    }
}